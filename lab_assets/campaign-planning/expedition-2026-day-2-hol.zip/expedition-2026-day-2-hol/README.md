# Campaign Planning, Simplified: Build It with CoCo, Ask It with CoWork

Companion files for the Expedition 2026 Day 2 hands-on lab. Follow the step-by-step guide on [Snowflake Developer Guides](https://www.snowflake.com/en/developers/guides/), which starts by bringing these files into a Snowsight Workspace (cloned from GitHub or uploaded as a folder).

| Path | What it is |
|---|---|
| `lab.ipynb` | The notebook you run in the lab |
| `data/` | The three raw campaign exports loaded in the lab |
| `campaign_timeline/streamlit_app.py` | The collision heatmap app |

## License

Copyright (c) Snowflake Inc. All rights reserved.
Licensed under the Apache 2.0 license.
